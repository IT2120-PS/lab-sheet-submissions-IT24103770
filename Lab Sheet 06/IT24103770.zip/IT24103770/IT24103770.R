getwd()
setwd("C:\\Users\\wcmpi\\OneDrive\\Desktop\\IT24103770")
#Q1
#Binomal distribution
pbinom(46, 50, 0.85,lower.tail = FALSE)

#Q2
#Number of calls received in given day
#poisson distribution
dpois(15, 12)